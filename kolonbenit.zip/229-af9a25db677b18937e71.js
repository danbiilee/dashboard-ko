"use strict";(self.webpackChunkkolonbenit=self.webpackChunkkolonbenit||[]).push([[229],{8718:(e,t,r)=>{r.d(t,{Z:()=>C});var a=r(7294),o=r(8840),n=r.n(o),l=r(5708),i=r.n(l);const s=r(9163).ZP.div`
  position: relative;
  flex: 1;
  display: flex;
  flex-direction: column;
  & > div {
    z-index: 1;
    flex: 1;
  }
  .today {
    position: absolute;
    bottom: -0.7rem;
    right: 1.9rem;
    padding: 0.3rem 0.7rem;
    background-color: #70ad47;
    border-radius: 3px;
    font-size: 1.2rem;
    text-shadow: 0px 1px 1px #000000f4;
  }
`;var c=r(381),m=r.n(c);const d={chart:{backgroundColor:"transparent",plotBackgroundColor:"#1B2A338B",style:{fontFamily:"KoPub Dotum"}},credits:{enabled:!1},title:{text:void 0},tooltip:{shared:!0,useHTML:!0,borderColor:"#5470805C",borderWidth:2,style:{fontSize:"1.3rem",fontWeight:"bold"}},legend:{align:"right",verticalAlign:"top",x:5,y:-15,itemStyle:{color:"#BDC1D1",fontSize:"1.2rem"},itemHoverStyle:{color:"#fff"},itemHiddenStyle:{color:"#626674"},symbolWidth:0,symbolHeight:0,symbolPadding:0,squareSymbol:!1,useHTML:!0,labelFormatter:function(){if("TOTAL"!==this.name)return`<div style='display: flex; align-items: center; cursor: pointer;'>\n                <span style='width: 1.2rem; height: 1.2rem; margin-right: 0.5rem; background-color: ${this.color}'></span>          \n                ${this.name}\n              </div>`}},yAxis:{title:{text:void 0},min:0,labels:{x:-10,style:{color:"#BDC1D1",fontSize:"1.2rem"}},gridLineColor:"#5470805C"},plotOptions:{column:{stacking:"normal",dataLabels:{enabled:!0,x:1,style:{textOutline:"none",fontSize:"1.3rem",color:"#fff"},formatter:function(){return this.y?this.y.toLocaleString():this.y}}}}},p={headerFormat:'<div style="padding-bottom: 0.5rem; border-bottom: 1px solid;">{point.key}</div>',pointFormatter:function(){const{y:e,series:t}=this;return`<div style='display: flex; align-items: center; margin-top: 0.8rem; z-index: 1;'>\n                <span style='width: 1.2rem; height: 1.2rem; margin-right: 0.5rem; background-color: ${this.color}'></span>\n                <span style='margin-right: 0.5rem;'>${t.name}</span>\n                <span style='padding-top: 0.2rem; font-size: 1.4rem;'>${e?e.toLocaleString():e}</span>\n              </div>`}},u=e=>{let t="";switch(e){case"week":t="dd";break;case"time":t="YYYY-MM-DD HH:mm";break;case"search":t="YYYY년 MM월"}return{formatter:function(){var e;const r=this.points;let a=`<div style="padding-bottom: 0.5rem; border-bottom: 1px solid;">${m()(null===(e=r[0])||void 0===e?void 0:e.x).locale("ko").format(t)}</div>`;for(let{color:e,y:t,series:r}of this.points){const{name:o}=r;"TOTAL"!==o&&(a+=`<div style='display: flex; align-items: center; margin-top: 0.8rem; z-index: 1;'>\n                    <span style='width: 1.4rem; height: 1.4rem; margin-right: 0.5rem; background-color: ${e}'></span>\n                    <span style='margin-right: 0.5rem;'>${o}</span>\n                    <span style='padding-top: 0.2rem; font-size: 1.8rem;'>${t?t.toLocaleString():t}</span>\n                  </div>`)}return a}}},h={...d,chart:{...d.chart,marginBottom:42},tooltip:{...d.tooltip,...p},xAxis:{categories:[],labels:{useHTML:!0,y:8,style:{color:"#BDC1D1",fontSize:"1rem"},formatter:function(){return`<span style='display: inline-block; max-width: 5rem; overflow: hidden; text-overflow: ellipsis; white-space:nowrap;'>${this.value}</span>`}},lineColor:"#5470805C",crosshair:!0},plotOptions:{...d.plotOptions,series:{groupPadding:.27}},series:[{name:"A급",type:"column",color:"#E6361F",borderWidth:0,data:[]},{name:"B급",type:"column",color:"#F5C010",borderWidth:0,data:[]}]},g={...d,chart:{...d.chart,marginBottom:42},tooltip:{...d.tooltip,...p},xAxis:{categories:[],labels:{useHTML:!0,y:8,style:{color:"#BDC1D1",fontSize:"1rem"},formatter:function(){return`<span style='display: inline-block; max-width: 5rem; overflow: hidden; text-overflow: ellipsis; white-space:nowrap;'>${this.value}</span>`}},lineColor:"#5470805C",crosshair:!0},plotOptions:{...d.plotOptions,series:{groupPadding:.27}},series:[{name:"심각",type:"column",color:"#E6361F",borderWidth:0,data:[]},{name:"경고",type:"column",color:"#F5C010",borderWidth:0,data:[]}]},f={week:{...d,chart:{...d.chart,marginBottom:40},tooltip:{...d.tooltip,...u("week")},xAxis:{categories:[],labels:{y:20,style:{color:"#BDC1D1",fontSize:"1.4rem"},formatter:function(){return m()(this.value).locale("ko").format("dd")}},lineColor:"#5470805C",crosshair:!0},plotOptions:{...d.plotOptions,column:{...d.plotOptions.column,stacking:void 0},series:{pointPadding:.11,groupPadding:.22}},series:[{name:"전주",type:"column",color:"#768894",borderWidth:0,data:[]},{name:"금주",type:"column",color:"#F5C010",borderWidth:0,data:[]}]},team:g,obs:h,time:{...d,chart:{...d.chart,marginBottom:25},legend:{...d.legend,x:25},tooltip:{...d.tooltip,...u("time")},xAxis:{categories:[],labels:{y:18,style:{color:"#BDC1D1",fontSize:"1rem"},formatter:function(){return m()(this.value).locale("ko").format("HH")},autoRotation:void 0},lineColor:"#5470805C",crosshair:!0},plotOptions:{...d.plotOptions,series:{groupPadding:0}},series:[{name:"심각",type:"column",color:"#E6361F",borderWidth:0,data:[]},{name:"경고",type:"column",color:"#F5C010",borderWidth:0,data:[]},{name:"TOTAL",type:"line",color:"#E6361F",data:[]}]},search:{...d,legend:{...d.legend,x:22,y:0,itemStyle:{...d.legend.itemStyle,fontSize:"1.4rem"}},tooltip:{...d.tooltip,style:{...d.tooltip.style,fontSize:"1.6rem"},...u("search")},xAxis:{categories:[],labels:{y:35,style:{color:"#BDC1D1",fontSize:"2.1rem"},formatter:function(){return m()(this.value).locale("ko").format("YYYY년 MM월")}},tickColor:"#5470805C",lineColor:"#5470805C",tickWidth:1,crosshair:!0},yAxis:{...d.yAxis,labels:{...d.yAxis.labels,x:-25,y:10,style:{...d.yAxis.labels.style,fontSize:"1.8rem"}}},plotOptions:{...d.plotOptions,series:{pointPadding:.06,groupPadding:.2},column:{...d.plotOptions.column,stacking:void 0},line:{dataLabels:{enabled:!0,style:{textOutline:"none",fontSize:"1.5rem"},formatter:function(){return this.y?this.y.toLocaleString():this.y}}}},series:[{name:"심각",type:"column",color:"#E6361F",borderWidth:0,dataLabels:{color:"#E6361F"},data:[]},{name:"경고",type:"column",color:"#F5C010",borderWidth:0,dataLabels:{color:"#F5C010"},data:[]},{name:"TOTAL",type:"line",color:"#A4F7FA",dataLabels:{y:-12,color:"#A4F7FA"},marker:{enabled:!1},data:[]}]}};var b=r(2503),y=r(7383);const v=async(e,t)=>{const r=await fetch(e),a=await r.json();return"week"===t||"time"===t?a.metrics.reverse():a.metrics};var E=r(3467);const x=({type:e,param:t})=>{const r="search"===e?e:"main",o="search"===e?void 0:e,[l,c]=(0,a.useState)(f[e]),{data:m,isLoading:d,isError:p}=((e,t,r)=>{let a;if(ENV.IS_LOCAL)a=`${ENV.API_URL.local}/${ENV.API_REST_URI.CHART[e]}`,"search"!==e&&(t&&(a+=`/${t}`),r&&(a+=`/tab=${r.tab}`)),a+=".json";else{const o="production";a=`${ENV.API_URL[o]}/${ENV.API_REST_URI.CHART[e]}`,t&&(a+=`/${t}`),r&&(a+=`?${(0,y.Wz)(r)}`)}const{data:o,error:n}=(0,b.ZP)([a,t],v,ENV.SWR_CONFIG[e.toUpperCase()]);return{data:o,isLoading:!o&&!n,isError:n}})(r,o,t);return(0,a.useEffect)((()=>{m&&c((t=>{let r={};return r={...t},r.xAxis.categories=(0,y.CP)(e,m),r.series=(0,y.gU)(e,m,t.series),r}))}),[m]),d?a.createElement(E.Z,{isLoading:d,size:"search"===e?"large":"default"}):p?a.createElement(E.Z,{isError:p}):a.createElement(a.Fragment,null,"team"===e||"obs"===e||m.length?a.createElement(s,null,a.createElement(i(),{highcharts:n(),options:l}),"week"===e&&a.createElement("span",{className:"today"},"TODAY")):a.createElement(E.Z,{isEmpty:!0}))},C=a.memo(x,y.wy)},3467:(e,t,r)=>{r.d(t,{Z:()=>l});var a=r(7294),o=r(1382);const n=r(9163).ZP.div`
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #768894;
`,l=({isLoading:e,size:t,isError:r,isEmpty:l})=>a.createElement(a.Fragment,null,e&&a.createElement(o.Z,{size:t}),r&&a.createElement(n,null,r.toString()),l&&a.createElement(n,null,"No data to display"))},7949:(e,t,r)=>{r.d(t,{D:()=>s,g:()=>c});var a=r(7294),o=r(9163);const n=o.ZP.section`
  display: flex;
  flex-direction: column;
  padding: 2rem;
  background-color: #14232b;
  .header {
    position: relative;
    text-align: center;
  }
  .icon {
    z-index: 1;
    position: absolute;
    top: 0;
    left: 0;
    width: 1.9rem;
    height: 2.3rem;
    &:hover + .tooltip {
      visibility: visible;
    }
  }
  .tooltip {
    position: absolute;
    top: -2.7rem;
    left: -3.3rem;
    padding: 0.5rem 0.8rem;
    background-color: #ffeeb4;
    border-radius: 0.3rem;
    color: #2d3940;
    font-size: 1.2rem;
    visibility: hidden;
    &::after {
      content: '';
      position: absolute;
      bottom: -0.4rem;
      left: 4rem;
      border: 0.3rem solid transparent;
      border-top: 0.4rem solid #ffeeb4;
      border-bottom: 0;
    }
  }
  .title {
    margin-bottom: 2rem;
    color: #fff;
    font-size: ${({titleSize:e})=>"lg"===e?"2.8rem":"2.5rem"};
  }
`,l=o.ZP.div`
  flex: 1;
  display: flex;
  height: 0;
`;var i=r(4673);const s=({title:e,tooltip:t,titleSize:r,children:o})=>a.createElement(n,{titleSize:r},a.createElement("div",{className:"header"},a.createElement("div",{className:"helper"},a.createElement("img",{className:"icon",src:i,alt:"help icon"}),a.createElement("div",{className:"tooltip"},t)),a.createElement("h2",{className:"title"},e)),a.createElement(l,null,o)),c=({children:e})=>a.createElement(l,null,e)},3391:(e,t,r)=>{r.d(t,{Z:()=>l});var a=r(7294),o=r(9163);const n=o.ZP.main`
  overflow: hidden;
  flex: 1;
  ${({type:e})=>"dashboard"===e?o.iv`
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          grid-template-rows: repeat(3, minmax(32.5%, 32.8%));
          gap: 1rem;
          height: 100%;
          padding: 2.4rem;
          section:nth-child(5) {
            grid-column: 2 / 4; // 알람 미조치 리스트 TOP5
          }
        `:o.iv`
          flex: 1 1 0%;
          display: flex;
          flex-direction: column;
          padding: 4rem 4.8rem;
        `}
`,l=({type:e,children:t})=>a.createElement(n,{type:e},t)},4229:(e,t,r)=>{r.r(t),r.d(t,{default:()=>F});var a=r(7294),o=r(3391),n=r(7949),l=r(9163);const i=l.ZP.div`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 12.8rem;
  margin-bottom: 4rem;
  background-color: #1b2a338b;
  border: 1px solid #5470805c;
  & > label:not(:last-of-type)::after {
    content: '';
    height: 3.5rem;
    padding: 0.5rem 3.2rem 0.5rem 0;
    margin-right: 3.2rem;
    border-right: 2px solid #708c9d5c;
  }
  button:last-of-type {
    margin-left: 3.2rem;
  }
  .ant-alert {
    position: absolute;
    top: -1rem;
    font-size: 2rem;
  }
  .ant-alert-warning {
    padding: 2rem 2.5rem 2.5rem 3rem;
    border: 1px solid #f5c010;
    .ant-alert-icon {
      margin-top: 0.1rem;
      color: #f5c010;
      font-size: 3rem;
    }
    .ant-alert-message {
      margin-bottom: 0.8rem;
      font-size: 2.1rem;
    }
    .ant-alert-description {
      font-size: 1.8rem;
    }
    .ant-alert-close-icon {
      margin-left: 15rem;
      font-size: 1.8rem;
      cursor: pointer;
      * {
        cursor: pointer;
      }
    }
  }
`,s=l.ZP.label`
  display: flex;
  align-items: center;
  .label {
    margin-right: 1rem;
    color: #aebfcb;
    font-size: 2.1rem;
  }
`,c=({name:e,children:t})=>a.createElement(s,null,a.createElement("span",{className:"label"},e),t),m=l.ZP.div`
  display: inline-block;
  .ant-select {
    height: 4.8rem;
    &.team {
      width: 30rem;
    }
    &.service {
      width: 38rem;
    }
  }
  .ant-select-selector,
  .ant-select-selector * {
    cursor: pointer;
  }
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    height: 100%;
    padding: 0 1rem;
    background-color: #33454d;
    border: 0;
    color: #fff;
    font-size: 2.3rem;
    font-weight: bold;
  }
  .ant-select-single .ant-select-selector .ant-select-selection-item {
    line-height: 4.8rem;
  }
  .ant-select-arrow {
    top: 0.6rem;
    right: 0;
    width: 4.9rem;
    height: 4.8rem;
  }
`;var d=r(1167),p=r(7604),u=r(7383);const{Option:h}=p.Z,g=({type:e,searchInputs:t,mappedNames:r,handleChange:o})=>{const n=null==r?void 0:r.find((e=>e.selected));return a.createElement(m,null,a.createElement(p.Z,{className:e,value:t[e],suffixIcon:a.createElement("img",{src:d,alt:"picker suffix"}),onChange:t=>{o(e,t)},listHeight:305},"team"===e?null==r?void 0:r.map(((t,r)=>a.createElement(h,{key:r,className:"option",value:"전체"===t[e]?"total":t[e]},t[e]))):null==n?void 0:n.service.map(((e,t)=>a.createElement(h,{key:t,className:"option",value:"전체"===e?"total":e},e)))))},f=a.memo(g,u.wy),b=l.ZP.div`
  display: inline-block;
  .tilde {
    margin: 0 1rem;
    color: #546f68;
    font-size: 2rem;
  }
  .ant-picker {
    width: 25.6rem;
    height: 4.8rem;
    background-color: #33454d;
    border: 0;
    outline: none;
    &:last-of-type {
      margin-right: 1.6rem;
    }
  }
  .ant-picker-input {
    cursor: pointer;
    input {
      color: #fff;
      font-size: 2.3rem;
      font-weight: bold;
      cursor: pointer !important;
    }
  }

  .ant-picker-clear {
    display: none;
  }
`;var y=r(9308),v=r(381),E=r.n(v),x=r(2569);const C=({searchInputs:e,handleChange:t})=>{const[r,o]=(0,a.useState)(!1);return a.createElement(b,null,a.createElement(y.Z,{picker:"month",placeholder:"시작일",suffixIcon:a.createElement("img",{src:x,alt:"picker suffix"}),value:E()(e.start_date),onChange:(e,r)=>{t("start_date",r)},disabledDate:t=>{if(!t||!e.end_date)return!1;const r=E()(e.end_date),a=t.valueOf()>r.valueOf(),o=t.valueOf()<r.subtract(11,"M").valueOf();return a||o},onOpenChange:e=>{e?setTimeout((()=>setTimeout((()=>{var e=document.getElementsByClassName("ant-picker-input");e.length>0&&e[0]&&e[0].blur()})))):o(!0)},allowClear:!1}),a.createElement("span",{className:"tilde"}," ~ "),a.createElement(y.Z,{picker:"month",placeholder:"종료일",suffixIcon:a.createElement("img",{src:x,alt:"picker suffix"}),value:E()(e.end_date),onChange:(e,r)=>{t("end_date",r)},disabledDate:t=>{if(!t||!e.start_date)return!1;const r=E()(e.start_date),a=t.valueOf()<=r.add(2,"M").valueOf(),o=t.valueOf()>r.add(11,"M").valueOf(),n=t.valueOf()>E()().valueOf();return a||o||n},onOpenChange:e=>{o(e);var t=document.getElementsByClassName("ant-picker-input");t.length>0&&t[0]&&t[0].blur()},open:r,allowClear:!1}))},k=a.memo(C),w=l.ZP.button`
  height: 4.8rem;
`,A=(0,l.ZP)(w)`
  width: 4.8rem;
`,S=(0,l.ZP)(w)`
  width: 10.4rem;
  border: 1px solid #528500;
  background-color: #1e3440;
`;var z=r(342);const O=({searchInputs:e,setAlert:t})=>a.createElement(A,{onClick:()=>{if(ENV.IS_LOCAL)return void alert("지원하지 않는 기능입니다");if("total"===e.team)return void t({status:!0,message:"팀명을 선택하세요"});if("total"===e.service)return void t({status:!0,message:"서비스명을 선택하세요"});const r=`${ENV.API_URL.production}/${ENV.API_REST_URI.EXCEL}?${(0,u.Wz)(e)}`;window.location.href=r}},a.createElement("img",{src:z,alt:"excel button"})),I=a.memo(O);var L=r(5002);const T=({searchInputs:e,setSearchInputs:t})=>a.createElement(S,{onClick:()=>{t(e)}},a.createElement("img",{src:L,alt:"search button"})),N=a.memo(T);var P=r(2690),_=r(164);const $={status:!1,message:""},Z=({searchInputs:e,setSearchInputs:t})=>{const r=(0,P.L_)(),o=(0,P.oM)(),[n,l]=(0,a.useState)(e),[s,m]=(0,a.useState)($),d=(0,a.useCallback)(((e,t)=>{if("team"===e){const e="total"===t?"전체":t,a=null==r?void 0:r.map((t=>t.team===e?{...t,selected:!0}:{...t,selected:!1}));o(a)}l((r=>({...r,[e]:t})))}),[r]);return(0,a.useEffect)((()=>{"total"!==n.service&&l((e=>({...e,service:"total"})))}),[n.team]),a.createElement(i,null,a.createElement(c,{name:"팀명"},a.createElement(f,{type:"team",searchInputs:n,mappedNames:r,handleChange:d})),a.createElement(c,{name:"서비스명"},a.createElement(f,{type:"service",searchInputs:n,mappedNames:r,handleChange:d})),a.createElement(c,{name:"기간"},a.createElement(k,{searchInputs:n,handleChange:d})),a.createElement(N,{searchInputs:n,setSearchInputs:t}),a.createElement(I,{searchInputs:n,setAlert:m}),s.status&&a.createElement(_.Z,{message:"Warning",description:s.message,type:"warning",showIcon:!0,closable:!0,afterClose:()=>m((e=>({...e,status:!1})))}))};var M=r(8718);const F=()=>{const[e,t]=(0,a.useState)({team:"total",service:"total",start_date:E()().subtract(5,"M").locale("ko").format("YYYY-MM"),end_date:E()().locale("ko").format("YYYY-MM")});return a.createElement(o.Z,{type:"status"},a.createElement(Z,{searchInputs:e,setSearchInputs:t}),a.createElement(n.g,null,a.createElement(M.Z,{type:"search",param:e})))}},7383:(e,t,r)=>{r.d(t,{Wz:()=>o,wy:()=>n,CP:()=>i,gU:()=>s});var a=r(8471);const o=e=>Object.entries(e).map((([e,t])=>`${encodeURIComponent(e)}=${encodeURIComponent(t)}`)).join("&");function n(e,t){return(0,a.J)(e,t)}const l=()=>TEAM_NAME.sort(((e,t)=>e.order-t.order)).map((e=>e.title)),i=(e,t)=>{let r=[];switch(e){case"obs":case"team":r=l();break;case"week":r=t.map((e=>e.THIS_WEEK));break;case"time":case"search":r=t.map((e=>e.DAY));break;default:console.log(`Get Chart Categories: ${e} is not allowed!`)}return r},s=(e,t,r)=>{let a=[];const o=l();let n=[],i=[],s=[];switch(e){case"obs":const l=[],c=[];for(let e of o){const r=t.find((t=>t.TEAM_NAME===e));l.push(r?r.A:0),c.push(r?r.B:0)}a=r.map((e=>"A급"===e.name?{...e,data:l}:{...e,data:c}));break;case"team":n=[],i=[];for(let e of o){const r=t.find((t=>t.TEAM_NAME===e));n.push(r?r.CRITICAL:0),i.push(r?r.TROUBLE:0)}a=r.map((e=>"심각"===e.name?{...e,data:n}:{...e,data:i}));break;case"week":const m=[],d=[];for(let{THIS_CNT:e,LAST_CNT:r}of t)m.push(e),d.push(r);a=r.map((e=>"금주"===e.name?{...e,data:m}:{...e,data:d}));break;case"time":case"search":n=[],i=[],s=[];for(let{CRITICAL:e,TROUBLE:r}of t)n.push(e),i.push(r),s.push(e+r);a=r.map((e=>"심각"===e.name?{...e,data:n}:"경고"===e.name?{...e,data:i}:{...e,data:s}));break;default:console.log(`Get Chart Series: ${e} is not allowed!`)}return a}},1167:(e,t,r)=>{e.exports=r.p+"assets/btn-dropdown-725b6695ea3e1916e386.png"},2569:(e,t,r)=>{e.exports=r.p+"assets/icon-daterange-d384c8d970809a5d0ad6.png"},342:(e,t,r)=>{e.exports=r.p+"assets/icon-excel-98c49ffb8be962d6e8be.png"},4673:(e,t,r)=>{e.exports=r.p+"assets/icon-help-36e1c2d4478a5a748aab.png"},5002:(e,t,r)=>{e.exports=r.p+"assets/icon-search-11caca94767c928b6886.png"}}]);